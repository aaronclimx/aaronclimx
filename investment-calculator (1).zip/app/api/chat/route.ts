import { OpenAIStream, StreamingTextResponse } from "ai"
import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"

// Financial knowledge base for the assistant
const FINANCIAL_KNOWLEDGE = `
You are a helpful financial assistant for an Investment & Loan Calculator App. 
You can help users understand financial concepts, explain how to use the calculators, and answer questions about investments and loans.

The app includes the following calculators:
1. Simple Interest Calculator - Calculates interest on fixed-rate investments using the formula SI = (P × R × T) / 100
2. Compound Interest Calculator - Projects growth with compounding interest using the formula A = P(1 + r/n)^(nt)
3. Loan Calculator - Calculates monthly payments and total interest using the formula M = P × (r(1+r)^n) / ((1+r)^n-1)
4. Investment Growth Calculator - Projects investment growth with regular contributions
5. Tax Estimation Calculator - Estimates taxes on income and investments

Provide helpful, concise answers about financial concepts. If users ask how to use a specific calculator, explain the inputs needed and what the results mean.
Always be professional and encouraging. If you don't know something, admit it and suggest they consult a financial advisor for personalized advice.
`

export async function POST(req: Request) {
  const { messages } = await req.json()

  // Generate a response with the AI SDK
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: [{ role: "system", content: FINANCIAL_KNOWLEDGE }, ...messages],
    temperature: 0.7,
    maxTokens: 500,
  })

  // Create a stream from the response
  const stream = OpenAIStream(text)

  // Return the stream as a streaming response
  return new StreamingTextResponse(stream)
}
