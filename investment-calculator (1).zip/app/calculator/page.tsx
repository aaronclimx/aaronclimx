"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import SimpleInterestCalculator from "@/components/calculators/simple-interest-calculator"
import CompoundInterestCalculator from "@/components/calculators/compound-interest-calculator"
import LoanCalculator from "@/components/calculators/loan-calculator"
import InvestmentGrowthCalculator from "@/components/calculators/investment-growth-calculator"
import TaxCalculator from "@/components/calculators/tax-calculator"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function CalculatorPage() {
  const [activeTab, setActiveTab] = useState("simple")

  return (
    <div className="container mx-auto max-w-5xl p-4 md:p-8">
      <div className="mb-6 flex items-center">
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-1">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
        </Link>
        <h1 className="ml-4 text-2xl font-bold md:text-3xl">Financial Calculators</h1>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader className="bg-slate-50 dark:bg-slate-900 rounded-t-lg">
          <CardTitle>Investment & Loan Calculator</CardTitle>
          <CardDescription>Calculate interest, loan payments, investment growth, and tax estimates</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 rounded-none border-b">
              <TabsTrigger value="simple">Simple Interest</TabsTrigger>
              <TabsTrigger value="compound">Compound Interest</TabsTrigger>
              <TabsTrigger value="loan">Loan</TabsTrigger>
              <TabsTrigger value="investment">Investment Growth</TabsTrigger>
              <TabsTrigger value="tax">Tax Estimation</TabsTrigger>
            </TabsList>
            <div className="p-4 md:p-6">
              <TabsContent value="simple">
                <SimpleInterestCalculator />
              </TabsContent>
              <TabsContent value="compound">
                <CompoundInterestCalculator />
              </TabsContent>
              <TabsContent value="loan">
                <LoanCalculator />
              </TabsContent>
              <TabsContent value="investment">
                <InvestmentGrowthCalculator />
              </TabsContent>
              <TabsContent value="tax">
                <TaxCalculator />
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
