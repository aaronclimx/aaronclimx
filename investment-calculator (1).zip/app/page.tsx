import type { Metadata } from "next"
import WelcomeScreen from "@/components/welcome-screen"

export const metadata: Metadata = {
  title: "Investment & Loan Calculator",
  description: "Calculate investments, loans, and financial projections with ease",
}

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 md:p-24">
      <WelcomeScreen />
    </main>
  )
}
