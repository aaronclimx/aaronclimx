import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LightbulbIcon } from "lucide-react"

interface ResultItem {
  label: string
  value: string | number
  highlighted?: boolean
}

interface ResultDisplayProps {
  title: string
  results: ResultItem[]
  insights?: string[]
  chart?: React.ReactNode
}

export default function ResultDisplay({ title, results, insights, chart }: ResultDisplayProps) {
  return (
    <Card className="mt-6">
      <CardHeader className="bg-slate-50 dark:bg-slate-900 rounded-t-lg">
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <div className="space-y-4">
              {results.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span className="text-muted-foreground">{item.label}:</span>
                  <span className={item.highlighted ? "font-bold text-lg" : "font-medium"}>{item.value}</span>
                </div>
              ))}
            </div>

            {insights && insights.length > 0 && (
              <div className="mt-6 space-y-2">
                <h3 className="flex items-center gap-1 font-medium">
                  <LightbulbIcon className="h-4 w-4 text-yellow-500" />
                  Insights
                </h3>
                <ul className="space-y-2">
                  {insights.map((insight, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      {insight}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {chart && <div>{chart}</div>}
        </div>
      </CardContent>
    </Card>
  )
}
