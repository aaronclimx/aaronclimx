"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InfoIcon } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency } from "@/lib/utils"
import ResultDisplay from "@/components/results/result-display"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const formSchema = z.object({
  income: z.coerce.number().positive("Income must be positive"),
  investmentIncome: z.coerce.number().min(0, "Investment income must be non-negative"),
  filingStatus: z.string(),
})

export default function TaxCalculator() {
  const [result, setResult] = useState(null)
  const [chartData, setChartData] = useState([])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      income: 75000,
      investmentIncome: 5000,
      filingStatus: "single",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    const income = values.income
    const investmentIncome = values.investmentIncome
    const filingStatus = values.filingStatus

    // Simplified tax brackets for 2023 (for demonstration purposes)
    const taxBrackets = {
      single: [
        { rate: 0.1, threshold: 0 },
        { rate: 0.12, threshold: 11000 },
        { rate: 0.22, threshold: 44725 },
        { rate: 0.24, threshold: 95375 },
        { rate: 0.32, threshold: 182100 },
        { rate: 0.35, threshold: 231250 },
        { rate: 0.37, threshold: 578125 },
      ],
      joint: [
        { rate: 0.1, threshold: 0 },
        { rate: 0.12, threshold: 22000 },
        { rate: 0.22, threshold: 89450 },
        { rate: 0.24, threshold: 190750 },
        { rate: 0.32, threshold: 364200 },
        { rate: 0.35, threshold: 462500 },
        { rate: 0.37, threshold: 693750 },
      ],
    }

    // Capital gains tax rates (simplified)
    const capitalGainsTaxRates = {
      single: [
        { rate: 0, threshold: 0 },
        { rate: 0.15, threshold: 44625 },
        { rate: 0.2, threshold: 492300 },
      ],
      joint: [
        { rate: 0, threshold: 0 },
        { rate: 0.15, threshold: 89250 },
        { rate: 0.2, threshold: 553850 },
      ],
    }

    // Calculate income tax
    const brackets = taxBrackets[filingStatus]
    let incomeTax = 0
    const taxableIncome = income
    const taxByBracket = []

    for (let i = 0; i < brackets.length; i++) {
      const currentBracket = brackets[i]
      const nextBracket = brackets[i + 1]
      const bracketIncome = nextBracket
        ? Math.min(taxableIncome, nextBracket.threshold) - currentBracket.threshold
        : taxableIncome - currentBracket.threshold

      if (bracketIncome > 0) {
        const bracketTax = bracketIncome * currentBracket.rate
        incomeTax += bracketTax
        taxByBracket.push({
          bracket: `${(currentBracket.rate * 100).toFixed(0)}%`,
          income: bracketIncome,
          tax: bracketTax,
        })
      }

      if (!nextBracket || taxableIncome <= nextBracket.threshold) break
    }

    // Calculate capital gains tax
    const capitalGainsBrackets = capitalGainsTaxRates[filingStatus]
    let capitalGainsTax = 0

    for (let i = 0; i < capitalGainsBrackets.length; i++) {
      const currentBracket = capitalGainsBrackets[i]
      const nextBracket = capitalGainsBrackets[i + 1]

      if (income > currentBracket.threshold) {
        const applicableRate = currentBracket.rate

        if (!nextBracket || income < nextBracket.threshold) {
          capitalGainsTax = investmentIncome * applicableRate
          break
        }
      }
    }

    const totalTax = incomeTax + capitalGainsTax
    const effectiveTaxRate = (totalTax / (income + investmentIncome)) * 100

    setChartData(taxByBracket)
    setResult({
      income,
      investmentIncome,
      filingStatus,
      incomeTax,
      capitalGainsTax,
      totalTax,
      effectiveTaxRate,
      afterTaxIncome: income + investmentIncome - totalTax,
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Tax Estimation Calculator</h2>
        <p className="text-muted-foreground">Estimate your income and investment taxes based on your filing status.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <FormField
              control={form.control}
              name="income"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Annual Income
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Your total taxable income for the year</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="investmentIncome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Investment Income
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Income from investments (capital gains, dividends)</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="filingStatus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Filing Status
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Your tax filing status</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="single">Single</SelectItem>
                      <SelectItem value="joint">Married Filing Jointly</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                form.reset()
                setResult(null)
                setChartData([])
              }}
            >
              Reset
            </Button>
            <Button type="submit">Calculate</Button>
          </div>
        </form>
      </Form>

      {result && (
        <ResultDisplay
          title="Tax Estimation Results"
          results={[
            { label: "Annual Income", value: formatCurrency(result.income) },
            { label: "Investment Income", value: formatCurrency(result.investmentIncome) },
            { label: "Filing Status", value: result.filingStatus === "single" ? "Single" : "Married Filing Jointly" },
            { label: "Income Tax", value: formatCurrency(result.incomeTax) },
            { label: "Capital Gains Tax", value: formatCurrency(result.capitalGainsTax) },
            { label: "Total Tax", value: formatCurrency(result.totalTax), highlighted: true },
            { label: "Effective Tax Rate", value: `${result.effectiveTaxRate.toFixed(2)}%` },
            { label: "After-Tax Income", value: formatCurrency(result.afterTaxIncome) },
          ]}
          insights={[
            `Your total tax liability is estimated at ${formatCurrency(result.totalTax)}.`,
            `Your effective tax rate is ${result.effectiveTaxRate.toFixed(2)}% of your total income.`,
            `After taxes, you'll have ${formatCurrency(result.afterTaxIncome)} available.`,
          ]}
          chart={
            chartData.length > 0 ? (
              <div className="mt-4">
                <h3 className="font-medium mb-2">Tax Breakdown by Bracket</h3>
                <div className="h-[300px] w-full">
                  <ChartContainer
                    config={{
                      tax: {
                        label: "Tax Amount",
                        color: "hsl(var(--chart-1))",
                      },
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="bracket" />
                        <YAxis tickFormatter={(value) => `$${value.toLocaleString()}`} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Bar dataKey="tax" fill="var(--color-tax)" name="Tax Amount" />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </div>
            ) : null
          }
        />
      )}
    </div>
  )
}
