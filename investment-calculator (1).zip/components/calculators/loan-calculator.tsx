"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { InfoIcon } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency } from "@/lib/utils"
import ResultDisplay from "@/components/results/result-display"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"
import { ChartContainer } from "@/components/ui/chart"

const formSchema = z.object({
  principal: z.coerce.number().positive("Loan amount must be positive"),
  rate: z.coerce.number().positive("Interest rate must be positive"),
  term: z.coerce.number().positive("Loan term must be positive"),
})

export default function LoanCalculator() {
  const [result, setResult] = useState(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      principal: 10000,
      rate: 5,
      term: 3,
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    const principal = values.principal
    const monthlyRate = values.rate / 100 / 12
    const numberOfPayments = values.term * 12

    // Calculate monthly payment: M = P × (r(1+r)^n) / ((1+r)^n-1)
    const monthlyPayment =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - principal

    setResult({
      principal,
      rate: values.rate,
      term: values.term,
      monthlyPayment,
      totalPayment,
      totalInterest,
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Loan Calculator</h2>
        <p className="text-muted-foreground">Calculate your monthly payments and total interest for a loan.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <FormField
              control={form.control}
              name="principal"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Loan Amount
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>The total amount borrowed</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="rate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Interest Rate
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Annual interest rate in percentage</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.01" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="term"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Loan Term
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Loan duration in years</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">years</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                form.reset()
                setResult(null)
              }}
            >
              Reset
            </Button>
            <Button type="submit">Calculate</Button>
          </div>
        </form>
      </Form>

      {result && (
        <ResultDisplay
          title="Loan Calculation Results"
          results={[
            { label: "Loan Amount", value: formatCurrency(result.principal) },
            { label: "Interest Rate", value: `${result.rate}%` },
            { label: "Loan Term", value: `${result.term} years` },
            { label: "Monthly Payment", value: formatCurrency(result.monthlyPayment), highlighted: true },
            { label: "Total Payment", value: formatCurrency(result.totalPayment) },
            { label: "Total Interest", value: formatCurrency(result.totalInterest) },
          ]}
          insights={[
            `Your monthly payment will be ${formatCurrency(result.monthlyPayment)}.`,
            `You will pay a total of ${formatCurrency(result.totalInterest)} in interest over the life of the loan.`,
            `The total cost of your loan will be ${formatCurrency(result.totalPayment)}.`,
          ]}
          chart={
            <div className="mt-4">
              <h3 className="font-medium mb-2">Payment Breakdown</h3>
              <div className="h-[250px]">
                <ChartContainer
                  config={{
                    principal: {
                      label: "Principal",
                      color: "hsl(var(--chart-1))",
                    },
                    interest: {
                      label: "Interest",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Principal", value: result.principal },
                          { name: "Interest", value: result.totalInterest },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="var(--color-principal)" />
                        <Cell fill="var(--color-interest)" />
                      </Pie>
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </div>
          }
        />
      )}
    </div>
  )
}
