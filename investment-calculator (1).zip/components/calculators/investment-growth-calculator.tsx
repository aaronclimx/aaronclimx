"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { InfoIcon } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency } from "@/lib/utils"
import ResultDisplay from "@/components/results/result-display"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const formSchema = z.object({
  initialInvestment: z.coerce.number().positive("Initial investment must be positive"),
  monthlyContribution: z.coerce.number().min(0, "Monthly contribution must be non-negative"),
  annualReturn: z.coerce.number().positive("Annual return must be positive"),
  years: z.coerce.number().positive("Investment period must be positive"),
  reinvestDividends: z.boolean().default(true),
})

export default function InvestmentGrowthCalculator() {
  const [result, setResult] = useState(null)
  const [chartData, setChartData] = useState([])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      initialInvestment: 10000,
      monthlyContribution: 500,
      annualReturn: 7,
      years: 10,
      reinvestDividends: true,
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    const initialInvestment = values.initialInvestment
    const monthlyContribution = values.monthlyContribution
    const annualReturn = values.annualReturn / 100
    const years = values.years
    const reinvestDividends = values.reinvestDividends

    let totalInvested = initialInvestment
    let finalBalance = initialInvestment
    const data = [{ year: 0, balance: initialInvestment, invested: initialInvestment }]

    for (let year = 1; year <= years; year++) {
      // Add monthly contributions for the year
      totalInvested += monthlyContribution * 12

      if (reinvestDividends) {
        // Compound growth with monthly contributions
        finalBalance = calculateCompoundGrowth(
          finalBalance,
          monthlyContribution,
          annualReturn,
          1, // 1 year at a time
        )
      } else {
        // Simple growth (dividends not reinvested) with monthly contributions
        const yearlyContributions = monthlyContribution * 12
        const yearlyReturn = finalBalance * annualReturn
        finalBalance = finalBalance + yearlyContributions + yearlyReturn
      }

      data.push({
        year,
        balance: Number.parseFloat(finalBalance.toFixed(2)),
        invested: Number.parseFloat(totalInvested.toFixed(2)),
      })
    }

    const totalReturn = finalBalance - totalInvested
    const returnPercentage = (totalReturn / totalInvested) * 100

    setChartData(data)
    setResult({
      initialInvestment,
      monthlyContribution,
      annualReturn: values.annualReturn,
      years,
      reinvestDividends,
      totalInvested,
      finalBalance,
      totalReturn,
      returnPercentage,
    })
  }

  function calculateCompoundGrowth(principal, monthlyContribution, annualRate, years) {
    const monthlyRate = annualRate / 12
    let balance = principal

    for (let i = 0; i < years * 12; i++) {
      balance = balance * (1 + monthlyRate) + monthlyContribution
    }

    return balance
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Investment Growth Calculator</h2>
        <p className="text-muted-foreground">
          Project how your investments will grow over time with regular contributions.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="initialInvestment"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Initial Investment
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>The amount you start with</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="monthlyContribution"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Monthly Contribution
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>How much you add each month</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="annualReturn"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Annual Return
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Expected annual return percentage</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.1" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="years"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Investment Period
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>How long you'll invest for</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">years</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="reinvestDividends"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                <div className="space-y-0.5">
                  <FormLabel>Reinvest Dividends</FormLabel>
                  <p className="text-sm text-muted-foreground">Automatically reinvest dividends and capital gains</p>
                </div>
                <FormControl>
                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
              </FormItem>
            )}
          />

          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                form.reset()
                setResult(null)
                setChartData([])
              }}
            >
              Reset
            </Button>
            <Button type="submit">Calculate</Button>
          </div>
        </form>
      </Form>

      {result && (
        <ResultDisplay
          title="Investment Growth Projection"
          results={[
            { label: "Initial Investment", value: formatCurrency(result.initialInvestment) },
            { label: "Monthly Contribution", value: formatCurrency(result.monthlyContribution) },
            { label: "Investment Period", value: `${result.years} years` },
            { label: "Total Invested", value: formatCurrency(result.totalInvested) },
            { label: "Final Balance", value: formatCurrency(result.finalBalance), highlighted: true },
            { label: "Total Return", value: formatCurrency(result.totalReturn) },
            { label: "Return Percentage", value: `${result.returnPercentage.toFixed(2)}%` },
          ]}
          insights={[
            `Your investment of ${formatCurrency(result.totalInvested)} will grow to ${formatCurrency(
              result.finalBalance,
            )} over ${result.years} years.`,
            `You'll earn ${formatCurrency(result.totalReturn)} in returns, a ${result.returnPercentage.toFixed(
              2,
            )}% return on your investment.`,
            `Your monthly contribution of ${formatCurrency(
              result.monthlyContribution,
            )} significantly boosts your long-term growth.`,
          ]}
          chart={
            <div className="mt-4">
              <h3 className="font-medium mb-2">Investment Growth Over Time</h3>
              <div className="h-[300px] w-full">
                <ChartContainer
                  config={{
                    balance: {
                      label: "Balance",
                      color: "hsl(var(--chart-1))",
                    },
                    invested: {
                      label: "Invested",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" label={{ value: "Years", position: "insideBottomRight", offset: -5 }} />
                      <YAxis
                        tickFormatter={(value) => `$${value.toLocaleString()}`}
                        label={{ value: "Amount ($)", angle: -90, position: "insideLeft" }}
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="balance"
                        stroke="var(--color-balance)"
                        activeDot={{ r: 8 }}
                        name="Balance"
                      />
                      <Line
                        type="monotone"
                        dataKey="invested"
                        stroke="var(--color-invested)"
                        strokeDasharray="5 5"
                        name="Invested"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </div>
          }
        />
      )}
    </div>
  )
}
