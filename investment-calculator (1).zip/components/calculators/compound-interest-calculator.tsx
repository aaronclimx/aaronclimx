"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InfoIcon } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency } from "@/lib/utils"
import ResultDisplay from "@/components/results/result-display"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const formSchema = z.object({
  principal: z.coerce.number().positive("Principal must be positive"),
  rate: z.coerce.number().positive("Rate must be positive"),
  time: z.coerce.number().positive("Time must be positive"),
  frequency: z.string(),
})

export default function CompoundInterestCalculator() {
  const [result, setResult] = useState(null)
  const [chartData, setChartData] = useState([])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      principal: 1000,
      rate: 5,
      time: 5,
      frequency: "1",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    const principal = values.principal
    const rate = values.rate / 100
    const time = values.time
    const n = Number.parseInt(values.frequency)

    // Calculate compound interest: A = P(1 + r/n)^(nt)
    const totalAmount = principal * Math.pow(1 + rate / n, n * time)
    const interest = totalAmount - principal

    // Generate chart data
    const data = []
    for (let t = 0; t <= time; t++) {
      const amount = principal * Math.pow(1 + rate / n, n * t)
      data.push({
        year: t,
        amount: Number.parseFloat(amount.toFixed(2)),
      })
    }

    setChartData(data)
    setResult({
      principal,
      rate: values.rate,
      time,
      frequency: n,
      interest,
      totalAmount,
      frequencyText: getFrequencyText(n),
    })
  }

  function getFrequencyText(frequency: number) {
    switch (frequency) {
      case 1:
        return "Annually"
      case 2:
        return "Semi-annually"
      case 4:
        return "Quarterly"
      case 12:
        return "Monthly"
      case 365:
        return "Daily"
      default:
        return `${frequency} times per year`
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Compound Interest Calculator</h2>
        <p className="text-muted-foreground">
          Calculate how your investment grows when interest is compounded over time.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="principal"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Principal Amount
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>The initial investment amount</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="rate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Interest Rate
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Annual interest rate in percentage</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.01" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="time"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Time Period
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Time period in years</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.1" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">years</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="frequency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Compounding Frequency
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>How often interest is compounded per year</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">Annually</SelectItem>
                      <SelectItem value="2">Semi-annually</SelectItem>
                      <SelectItem value="4">Quarterly</SelectItem>
                      <SelectItem value="12">Monthly</SelectItem>
                      <SelectItem value="365">Daily</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                form.reset()
                setResult(null)
                setChartData([])
              }}
            >
              Reset
            </Button>
            <Button type="submit">Calculate</Button>
          </div>
        </form>
      </Form>

      {result && (
        <ResultDisplay
          title="Compound Interest Results"
          results={[
            { label: "Principal Amount", value: formatCurrency(result.principal) },
            { label: "Interest Rate", value: `${result.rate}%` },
            { label: "Time Period", value: `${result.time} years` },
            { label: "Compounding Frequency", value: result.frequencyText },
            { label: "Interest Earned", value: formatCurrency(result.interest) },
            { label: "Total Amount", value: formatCurrency(result.totalAmount), highlighted: true },
          ]}
          insights={[
            `You will earn ${formatCurrency(result.interest)} in interest over ${result.time} years.`,
            `Your investment will grow by ${((result.interest / result.principal) * 100).toFixed(2)}% over the entire period.`,
            `Compounding ${result.frequencyText.toLowerCase()} increases your returns compared to simple interest.`,
          ]}
          chart={
            <div className="mt-4">
              <h3 className="font-medium mb-2">Investment Growth Over Time</h3>
              <div className="h-[300px] w-full">
                <ChartContainer
                  config={{
                    amount: {
                      label: "Amount",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" label={{ value: "Years", position: "insideBottomRight", offset: -5 }} />
                      <YAxis
                        tickFormatter={(value) => `$${value}`}
                        label={{ value: "Amount ($)", angle: -90, position: "insideLeft" }}
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="amount"
                        stroke="var(--color-amount)"
                        activeDot={{ r: 8 }}
                        name="Amount"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </div>
          }
        />
      )}
    </div>
  )
}
