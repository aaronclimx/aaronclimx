"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { InfoIcon } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency } from "@/lib/utils"
import ResultDisplay from "@/components/results/result-display"

const formSchema = z.object({
  principal: z.coerce.number().positive("Principal must be positive"),
  rate: z.coerce.number().positive("Rate must be positive"),
  time: z.coerce.number().positive("Time must be positive"),
})

export default function SimpleInterestCalculator() {
  const [result, setResult] = useState(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      principal: 1000,
      rate: 5,
      time: 1,
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Calculate simple interest: SI = (P × R × T) / 100
    const interest = (values.principal * values.rate * values.time) / 100
    const totalAmount = values.principal + interest

    setResult({
      interest,
      totalAmount,
      principal: values.principal,
      rate: values.rate,
      time: values.time,
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Simple Interest Calculator</h2>
        <p className="text-muted-foreground">
          Calculate the interest earned on an investment at a fixed rate over a period of time.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <FormField
              control={form.control}
              name="principal"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Principal Amount
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>The initial investment amount</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input type="number" className="pl-7" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="rate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Interest Rate
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Annual interest rate in percentage</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.01" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="time"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Time Period
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <InfoIcon className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Time period in years</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input type="number" step="0.1" {...field} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">years</span>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                form.reset()
                setResult(null)
              }}
            >
              Reset
            </Button>
            <Button type="submit">Calculate</Button>
          </div>
        </form>
      </Form>

      {result && (
        <ResultDisplay
          title="Simple Interest Results"
          results={[
            { label: "Principal Amount", value: formatCurrency(result.principal) },
            { label: "Interest Rate", value: `${result.rate}%` },
            { label: "Time Period", value: `${result.time} years` },
            { label: "Interest Earned", value: formatCurrency(result.interest) },
            { label: "Total Amount", value: formatCurrency(result.totalAmount), highlighted: true },
          ]}
          insights={[
            `You will earn ${formatCurrency(result.interest)} in interest over ${result.time} years.`,
            `Your investment will grow by ${((result.interest / result.principal) * 100).toFixed(2)}% over the entire period.`,
          ]}
        />
      )}
    </div>
  )
}
