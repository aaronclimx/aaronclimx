"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calculator, TrendingUp, Landmark, PiggyBank, BarChart4 } from "lucide-react"
import Link from "next/link"

export default function WelcomeScreen() {
  return (
    <Card className="w-full max-w-3xl shadow-lg">
      <CardHeader className="text-center bg-gradient-to-r from-blue-50 to-slate-50 dark:from-blue-950/50 dark:to-slate-950/50 rounded-t-lg">
        <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
          <Calculator className="h-8 w-8 text-blue-600 dark:text-blue-400" />
        </div>
        <CardTitle className="text-2xl md:text-3xl">Investment & Loan Calculator</CardTitle>
        <CardDescription className="text-base md:text-lg">
          Make informed financial decisions with our easy-to-use calculators
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 md:p-8">
        <div className="grid gap-6 md:grid-cols-2">
          <FeatureCard
            icon={<TrendingUp className="h-5 w-5 text-blue-600" />}
            title="Interest Calculators"
            description="Calculate simple and compound interest on your investments"
          />
          <FeatureCard
            icon={<Landmark className="h-5 w-5 text-blue-600" />}
            title="Loan Calculator"
            description="Determine monthly payments and total interest on loans"
          />
          <FeatureCard
            icon={<PiggyBank className="h-5 w-5 text-blue-600" />}
            title="Investment Growth"
            description="Project how your investments will grow over time"
          />
          <FeatureCard
            icon={<BarChart4 className="h-5 w-5 text-blue-600" />}
            title="Tax Estimation"
            description="Estimate taxes on your investments and income"
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-center bg-slate-50 dark:bg-slate-900 p-6 rounded-b-lg">
        <Link href="/calculator">
          <Button size="lg" className="w-full md:w-auto">
            Get Started
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="flex space-x-4 rounded-lg border p-4 transition-all hover:bg-slate-50 dark:hover:bg-slate-900">
      <div className="mt-0.5">{icon}</div>
      <div>
        <h3 className="font-medium">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  )
}
